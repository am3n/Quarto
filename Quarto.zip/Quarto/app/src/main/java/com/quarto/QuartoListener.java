package com.quarto;

import android.view.View;

public interface QuartoListener {

    void onDrop(int qid, View view);

}
